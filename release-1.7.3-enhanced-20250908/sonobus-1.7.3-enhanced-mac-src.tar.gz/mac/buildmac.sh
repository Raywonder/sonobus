#!/bin/bash

cd ..
rm -rf build

./setupcmake.sh

./buildcmake.sh



