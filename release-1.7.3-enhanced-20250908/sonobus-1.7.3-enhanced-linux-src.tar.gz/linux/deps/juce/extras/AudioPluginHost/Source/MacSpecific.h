#pragma once

#if JUCE_MAC
void disableAppNap();
#endif


