SonoBus Enhanced - Windows Distribution

INSTALLATION
============
Run install.bat as Administrator, or use install.ps1 with PowerShell.

FEATURES  
========
- Real-time network audio streaming
- VST3 plugin hosting support
- Low-latency audio processing
- Windows-optimized performance

PLUGIN HOSTING
=============
This version includes VST3 plugin hosting support:

User plugins: %USERPROFILE%\AppData\Roaming\VST3\
System plugins: %COMMONPROGRAMFILES%\VST3\

SYSTEM REQUIREMENTS
==================
- Windows 10 or later
- ASIO-compatible audio interface (recommended)
- DirectSound/WASAPI support
- .NET Framework 4.7.2 or later

SUPPORT
=======
For issues and support, visit: https://github.com/essej/sonobus
