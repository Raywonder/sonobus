# SonoBus Enhanced Windows Installer
param(
    [switch]$Elevated
)

Write-Host "=== SonoBus Enhanced Windows Installer ===" -ForegroundColor Green

# Check for admin privileges
if (-NOT $Elevated -AND -NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "This installer requires administrator privileges." -ForegroundColor Yellow
    Write-Host "Relaunching with elevated permissions..." -ForegroundColor Yellow
    
    Start-Process PowerShell -ArgumentList "-File `"$PSCommandPath`" -Elevated" -Verb RunAs
    exit
}

Write-Host "Installing SonoBus Enhanced..." -ForegroundColor Green

# Create installation directory
$InstallDir = "$env:ProgramFiles\SonoBus Enhanced"
if (!(Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    Write-Host "Created installation directory: $InstallDir" -ForegroundColor Green
}

# Copy files (placeholder for actual binary)
Copy-Item "sonobus.bat" $InstallDir -Force

# Create plugin directories
$VST3Dir = "$env:CommonProgramFiles\VST3\SonoBus"
if (!(Test-Path $VST3Dir)) {
    New-Item -ItemType Directory -Path $VST3Dir -Force | Out-Null
    Write-Host "Created VST3 plugin directory: $VST3Dir" -ForegroundColor Green
}

# Create desktop shortcut
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = "$DesktopPath\SonoBus Enhanced.lnk"
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "$InstallDir\sonobus.bat"
$Shortcut.Save()
Write-Host "Created desktop shortcut" -ForegroundColor Green

# Create Start Menu entry
$StartMenuPath = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
$StartMenuShortcut = "$StartMenuPath\SonoBus Enhanced.lnk"
$Shortcut = $WshShell.CreateShortcut($StartMenuShortcut)
$Shortcut.TargetPath = "$InstallDir\sonobus.bat"
$Shortcut.Save()
Write-Host "Created Start Menu entry" -ForegroundColor Green

Write-Host ""
Write-Host "SonoBus Enhanced installed successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "Plugin hosting is enabled:" -ForegroundColor Cyan
Write-Host "- VST3 plugins: $env:USERPROFILE\AppData\Roaming\VST3" -ForegroundColor Cyan
Write-Host "- System VST3: $env:CommonProgramFiles\VST3" -ForegroundColor Cyan
Write-Host ""
Write-Host "You can now run SonoBus from the desktop shortcut or Start Menu." -ForegroundColor Green

Read-Host "Press Enter to exit"
