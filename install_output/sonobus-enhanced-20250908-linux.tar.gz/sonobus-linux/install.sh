#!/bin/bash
set -e

echo "=== SonoBus Enhanced Linux Installer ==="
echo "Installing SonoBus with VST plugin hosting support..."

# Check for root/sudo
if [ "$EUID" -ne 0 ] && ! sudo -n true 2>/dev/null; then
    echo "This installer requires sudo access for system installation."
    echo "Run: sudo $0"
    exit 1
fi

INSTALL_PREFIX="/usr/local"
USER_HOME="$SUDO_USER_HOME"
[ -z "$USER_HOME" ] && USER_HOME="$HOME"

echo "Installing to: $INSTALL_PREFIX"

# Create directories
mkdir -p "$INSTALL_PREFIX/bin"
mkdir -p "$INSTALL_PREFIX/lib/vst3"
mkdir -p "$INSTALL_PREFIX/lib/lv2"
mkdir -p "$INSTALL_PREFIX/share/applications"
mkdir -p "$INSTALL_PREFIX/share/pixmaps"

# Install files
cp bin/sonobus "$INSTALL_PREFIX/bin/"
cp -r plugins/* "$INSTALL_PREFIX/lib/" 2>/dev/null || true
cp share/applications/sonobus.desktop "$INSTALL_PREFIX/share/applications/"
cp share/pixmaps/sonobus.* "$INSTALL_PREFIX/share/pixmaps/" 2>/dev/null || true

# Set permissions
chmod +x "$INSTALL_PREFIX/bin/sonobus"

# Update desktop database
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$INSTALL_PREFIX/share/applications"
fi

echo "SonoBus Enhanced installed successfully!"
echo "You can now run 'sonobus' from the command line or find it in your applications menu."
echo ""
echo "VST plugin hosting is enabled - place VST3 plugins in:"
echo "  $USER_HOME/.vst3/"
echo "  $INSTALL_PREFIX/lib/vst3/"
echo ""
echo "LV2 plugins will be loaded from:"
echo "  $USER_HOME/.lv2/"
echo "  $INSTALL_PREFIX/lib/lv2/"
