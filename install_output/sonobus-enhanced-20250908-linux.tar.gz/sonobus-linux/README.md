# SonoBus Enhanced - Linux Distribution

## Installation

Run the installer with sudo privileges:
```bash
sudo ./install.sh
```

## Features

- Real-time network audio streaming
- VST3 and LV2 plugin hosting support
- Low-latency audio processing
- Cross-platform compatibility

## Plugin Hosting

This version includes support for hosting VST3 and LV2 plugins:

- VST3 plugins: Place in `~/.vst3/` or `/usr/local/lib/vst3/`
- LV2 plugins: Place in `~/.lv2/` or `/usr/local/lib/lv2/`

## Dependencies

Required system packages:
- JACK Audio Connection Kit or ALSA
- libopus
- X11 development libraries
- freetype
- libcurl

Install with:
```bash
# Ubuntu/Debian
sudo apt install jackd2 libopus0 libx11-6 libfreetype6 libcurl4

# Fedora/CentOS
sudo dnf install jack-audio-connection-kit opus libX11 freetype libcurl
```

## Support

For issues and support, visit: https://github.com/essej/sonobus
