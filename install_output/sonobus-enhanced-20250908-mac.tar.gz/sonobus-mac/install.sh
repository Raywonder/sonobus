#!/bin/bash
set -e

echo "=== SonoBus Enhanced macOS Installer ==="

# Check if running on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "This installer is for macOS only"
    exit 1
fi

echo "Installing SonoBus Enhanced.app to /Applications..."

# Remove existing installation
if [ -d "/Applications/SonoBus.app" ]; then
    echo "Removing existing SonoBus installation..."
    rm -rf "/Applications/SonoBus.app"
fi

# Copy app bundle
cp -R "SonoBus.app" "/Applications/"

# Set permissions
chmod -R 755 "/Applications/SonoBus.app"

echo "SonoBus Enhanced installed successfully!"
echo ""
echo "Plugin hosting is enabled:"
echo "- AU plugins: ~/Library/Audio/Plug-Ins/Components/"
echo "- VST3 plugins: ~/Library/Audio/Plug-Ins/VST3/"
echo ""
echo "You can now find SonoBus Enhanced in your Applications folder."
